const header = `
/*
       _____  ____________
      / /   |/_  __/ ____/
 __  / / /| | / / / __/   
/ /_/ / ___ |/ / / /___   
 ____/_/  |_/_/ /_____/   
just another text editor
*/                          
`;

export { header };
